"""CLI unit tests package."""
